package com.onlinequizserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinequizserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
