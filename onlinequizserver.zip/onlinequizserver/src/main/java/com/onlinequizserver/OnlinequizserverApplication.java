package com.onlinequizserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinequizserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinequizserverApplication.class, args);
	}

}
